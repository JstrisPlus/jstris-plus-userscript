
var s = document.createElement('script');
s.src = browser.runtime.getURL('jstris-plus.js');
(document.head || document.documentElement).appendChild(s);
