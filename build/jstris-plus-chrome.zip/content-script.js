
var s = document.createElement('script');
s.src = chrome.runtime.getURL('jstris-plus.js');
(document.head || document.documentElement).appendChild(s);
